'''
authors: Wojciech Maciejewski
'''