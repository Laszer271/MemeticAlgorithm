'''
authors: Wojciech Maciejewski, Christian Konopczyński
'''
def n_best_select(data, count, cost_function):
    sorted_data = data.copy()
    sorted_data.sort(key=cost_function, reverse=True)
    return sorted_data[: count]