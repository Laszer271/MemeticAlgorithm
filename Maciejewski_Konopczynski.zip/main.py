'''
authors: Wojciech Maciejewski, Christian Konopczyński
'''

import tests
from evolution import models
import matplotlib.pyplot as plt

import time

if __name__ == '__main__':
    
    data = []
    
    for i in range(50):
        data.append(tests.generate_data3())
        
    start = time.time()
    model = models.Evolutional(cost_function=tests.cost_function3,
                               select_parents='proportional',
                               reproduce='mean',
                               mutate='1+1',
                               select_population='n_best')
        
    history = model.train(starting_population=data,
                          epochs=1000,
                          population_size=50,
                          offspring_size=50,
                          parents_per_child=2)
    
    optimum = model.current_best
    print(time.time() - start)
    
    start = time.time()
    memetic_model = models.Memetic(cost_function=tests.cost_function3,
                                   cost_functions_gradient=tests.gradient_for_cost_function3,
                                   select_parents='proportional',
                                   reproduce='mean',
                                   mutate='1+1',
                                   select_population='n_best')
    
    memetic_history = memetic_model.train(starting_population=data,
                                          epochs=1000,
                                          population_size=50,
                                          offspring_size=50,
                                          parents_per_child=2,
                                          memetic_learning_rate=0.1)
    
    memetic_optimum = memetic_model.current_best
    print(time.time() - start)

    fig, ax = plt.subplots()
    ax.scatter(range(len(history)), history, label='evolutional')
    ax.scatter(range(len(memetic_history)), memetic_history, label='memetic')
    
    plt.ylabel('fitness function')
    plt.xlabel('number of epochs')
    ax.legend()
    ax.grid(True)
    
    plt.show()
    
    fig.savefig('epochs1000_popsize100_offspringsize50_trainableparameters50.png')
